﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MLZZF.SocketClient.Tcp;
using MLZZF.Tool;

namespace TcpClientPro
{
    class Program
    {
        static TcpClient_MLZZF tcpClient;

        static Thread resetLink_thread;

        static void Main(string[] args)
        {
            tcpClient = new TcpClient_MLZZF("127.0.0.1", 60000);

            tcpClient.onConnected += new TcpClient_MLZZF.args_1(() =>
            {
                //连接成功
                Log.InFo("连接tcp服务成功...");
            });

            tcpClient.onReceive += new TcpClient_MLZZF.args_2((buff) =>
            {
                string str = Encoding.UTF8.GetString(buff);//消息解析
                Log.InFo("服务器发来消息: " + str);
            });


            tcpClient.onDisconnect += new TcpClient_MLZZF.args_1(() =>
            {
                //连接断开
                //开始重连
                Log.InFo("与tcp服务断开连接...");
                ResetLink();
            });


            if (!tcpClient.Start())
            {
                //连接失败
                //开始重连
                ResetLink();
            }


            while (true)
            {
                Console.WriteLine("输入要发送信息：");
                string str = Console.ReadLine();
                byte[] buff = Encoding.UTF8.GetBytes(str);
                tcpClient.Send(buff);
            }

        }

        static void ResetLink()
        {
            Log.InFo("开始重连...");
            if(resetLink_thread != null)
            {
                resetLink_thread.Abort();
                resetLink_thread = null;
            }

            resetLink_thread = new Thread(() =>
            {
                int count = 1;
                while (true)
                {
                    if (tcpClient.ResetLink())
                    {
                        //重连成功
                        Log.InFo("重新连接到tcp服务器...");
                        break;
                    }
                    else
                    {
                        //重连失败
                        Log.Warning("第" + count + "次重连失败...");
                    }
                    if(count >= 5)
                    {
                        //重连超时
                        Log.Error("重连超时...");
                        break;
                    }
                    count++;

                    Thread.Sleep(1000);//延迟1秒
                }
            });
            resetLink_thread.Start();
        }
    }
}
