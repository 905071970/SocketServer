﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using MLZZF.SocketServer.Udp;
using MLZZF.Tool;

namespace UdpServerPro
{
    class Program
    {
        static UdpServer_MLZZF udpServer;//udp服务

        static void Main(string[] args)
        {
            udpServer = new UdpServer_MLZZF(IPAddress.Any, 60001);//初始化udp服务

            //接收客户端消息事件
            udpServer.onReceive += new UdpServer_MLZZF.args_1((id,buff) =>
            {
                string str = Encoding.UTF8.GetString(buff);//消息解析
                Log.InFo("客户端: " + id + " 消息: " + str);

                foreach(var v in udpServer.allClient)
                {
                    udpServer.Send(v, buff);//进行消息转发
                }
            });


            if (udpServer.Start())
            {
                //udp服务启动成功
                Log.InFo("udp服务启动成功...");
            }
            else
            {
                //udp服务启动失败
                Log.Warning("udp服务启动失败...");
            }


            Console.ReadKey();
        }
    }
}
