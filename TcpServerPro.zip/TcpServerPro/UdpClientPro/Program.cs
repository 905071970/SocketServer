﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLZZF.SocketClient.Udp;
using MLZZF.Tool;

namespace UdpClientPro
{
    class Program
    {
        static UdpClient_MLZZF udpClient;

        static void Main(string[] args)
        {
            udpClient = new UdpClient_MLZZF("127.0.0.1", 60001);

            udpClient.onReceive += new UdpClient_MLZZF.args_1((buff) =>
            {
                string str = Encoding.UTF8.GetString(buff);
                Log.InFo("udp服务器发来消息: " + str);

            });


            if (udpClient.Start())
            {
                Log.InFo("udp客户端启动成功...");
            }
            else
            {
                Log.Warning("udp客户端启动出错...");
            }

            while (true)
            {
                Console.WriteLine("输入要发送信息：");
                string str = Console.ReadLine();

                byte[] data = Encoding.UTF8.GetBytes(str);
                udpClient.Send(data);
            }

        }
    }
}
